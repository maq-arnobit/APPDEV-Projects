export default function Header () {
    return (
        <>
        <header>
            <center>
                <h1>grocery</h1>
            </center>
        </header>
        </>
    )
}